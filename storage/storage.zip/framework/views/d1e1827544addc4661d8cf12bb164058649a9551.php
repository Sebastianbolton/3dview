

<?php $__env->startSection('title',\App\CPU\translate('3D Design')); ?>

<?php $__env->startPush('css_or_js'); ?>
<meta property="og:image" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="og:title" content="Brands of <?php echo e($web_config['name']->value); ?> "/>
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">

    <meta property="twitter:card" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="twitter:title" content="Brands of <?php echo e($web_config['name']->value); ?>"/>
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="twitter:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">
    <style>
        .page-item.active .page-link {
            background-color: <?php echo e($web_config['primary_color']); ?>    !important;
        }
        .design-items p, .design-items span {
          margin: 0 1px;
          padding: 0 1px;
        }
        .design-items p {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .design-items p:hover {
          overflow: visible;
          text-overflow: clip;
        }
    </style>

  <link href="public/css/bootstrap.css" rel="stylesheet">
  <link href="public/css/example.css" rel="stylesheet">

  <script src="public/js/three.min.js"></script>
  <script src="public/js/blueprint3d.js"></script>

  <script src="public/js/jquery.js"></script>
  <script src="public/js/bootstrap.js"></script>

  <script src="public/js/items.js"></script>
  <script src="public/js/example.js"></script>

  <script language="javascript" type="text/javascript">
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="startdesigningpage" style="width: 100%;">
            <div class="designimage">
                <div class="contentdesign">
                    <div class="designtitle" style="text-align: center;">
                        Design Your Interior Online
                    </div>
                    <div class="arrangementbutton">
                        <div class="buttongroup">
                            <a class="saveddesigning">Your Saved Designs</a>
                            <a class="startdesigning" href="<?php echo e(route('design')); ?> "><?php echo e(\App\CPU\translate('Start Designing')); ?></a>
                            <!-- <button class="startdesigning" onclick="route('design')">Start Designing</button> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\resources\views/design/startdesign.blade.php ENDPATH**/ ?>