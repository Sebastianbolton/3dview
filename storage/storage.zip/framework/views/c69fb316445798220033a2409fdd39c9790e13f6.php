<div class="inline-page-menu my-4">
    <ul class="list-unstyled">
        <li class="<?php echo e(Request::is('admin/business-settings/terms-condition') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.terms-condition')); ?>"><?php echo e(\App\CPU\translate('Terms_&_Conditions')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/business-settings/privacy-policy') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.privacy-policy')); ?>"><?php echo e(\App\CPU\translate('Privacy_Policy')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/business-settings/page/refund-policy') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.page',['refund-policy'])); ?>"><?php echo e(\App\CPU\translate('Refund_Policy')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/business-settings/page/return-policy') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.page',['return-policy'])); ?>"><?php echo e(\App\CPU\translate('Return_Policy')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/business-settings/page/cancellation-policy') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.page',['cancellation-policy'])); ?>"><?php echo e(\App\CPU\translate('Cancellation_Policy')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/business-settings/about-us') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.about-us')); ?>"><?php echo e(\App\CPU\translate('About_Us')); ?></a></li>
        <li class="<?php echo e(Request::is('admin/helpTopic/list') ?'active':''); ?>"><a href="<?php echo e(route('admin.helpTopic.list')); ?>"><?php echo e(\App\CPU\translate('FAQ')); ?></a></li>
        <?php if(theme_root_path() == 'theme_fashion'): ?>
        <li class="<?php echo e(Request::is('admin/business-settings/features-section') ?'active':''); ?>"><a href="<?php echo e(route('admin.business-settings.features-section')); ?>"><?php echo e(translate('features_Section')); ?></a></li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH D:\Xampp\htdocs\resources\views/admin-views/business-settings/pages-inline-menu.blade.php ENDPATH**/ ?>