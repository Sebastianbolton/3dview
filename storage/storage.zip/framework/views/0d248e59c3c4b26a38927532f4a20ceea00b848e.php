
<div class="footer">
    <div class="row justify-content-between align-items-center">
        <div class="col mt-3">
            <span><?php echo e(\App\CPU\translate('Copyright')); ?> &copy; <?php echo e(url('/')); ?> <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</div>
<?php /**PATH D:\Xampp\htdocs\resources\views/layouts/back-end/partials-seller/_footer.blade.php ENDPATH**/ ?>