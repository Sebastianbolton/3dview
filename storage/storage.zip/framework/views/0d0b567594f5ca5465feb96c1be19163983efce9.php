<div class="inline-page-menu my-4">
    <ul class="list-unstyled">
        <li class="<?php echo e(Request::is('seller/report/all-product') ?'active':''); ?>"><a href="<?php echo e(route('seller.report.all-product')); ?>"><?php echo e(\App\CPU\translate('All_Products')); ?></a></li>
        <li class="<?php echo e(Request::is('seller/report/stock-product-report') ?'active':''); ?>"><a href="<?php echo e(route('seller.report.stock-product-report')); ?>"><?php echo e(\App\CPU\translate('Products_Stock')); ?></a></li>
    </ul>
</div>
<?php /**PATH D:\Xampp\htdocs\resources\views/seller-views/report/product-report-inline-menu.blade.php ENDPATH**/ ?>